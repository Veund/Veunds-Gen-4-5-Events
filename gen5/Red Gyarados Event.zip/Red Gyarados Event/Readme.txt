Red gyarados made by Veund

use something like to pkhex to import the pgf file 

or use xdelta to patch the Liberty Pass Distribution 
rom and run the created rom on an R4 or similar device
to get working on an official game easily 

